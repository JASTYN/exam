'''
Author: Audrey Mbogho
Date: 20/01/2021
Purpose: Calculates the area of a
circle using a radius provide by
th user
'''
#from math import pi

PI = 3.14
r = float(input("Enter a radius: ")) # r is the radius
area1 = PI * r * r

print("The area of your circle is " + str(area1))

# print("The area of your circle is", area1)

# builtin functions are automaticall available.
# your don't have to import any library to use them
# examples are: len, max, min, abs
# write a program that asks the user for a length and a width
# and prints out the area of the rectangle.
