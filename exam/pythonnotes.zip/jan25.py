greetings = int(input("How many greetings do you want? "))
for count in range(greetings):
    print("Hello")
    print("Welcome")
