print("type(3.5)")
print("Hello")
