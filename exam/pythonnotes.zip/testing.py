print("Hello World")
print(3 + 7)
print("Thank you")
