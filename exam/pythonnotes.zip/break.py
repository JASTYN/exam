for number in range(1,10):
    print(number)
    if number % 7 == 0:
        break
 
print()

x = 1
while x < 10:
    print(x)
    if x % 7 == 0:
        break
    x += 1

    
